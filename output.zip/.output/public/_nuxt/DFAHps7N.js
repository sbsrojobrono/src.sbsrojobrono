import{_ as r,Q as t}from"./9oup8Y81.js";const s={};function n(e,o){return t(e.$slots,"default")}const a=r(s,[["render",n]]);export{a as default};
